package com.project.E_Commerce.Entities;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Carrier {
	@Id
	private int id;
	private String name;
	private long mob;
	private String email;
	private int capacity;
	private List<Order> orders;
	public Carrier(int id, String name, long mob, String email, int capacity, List<Order> orders) {
		super();
		this.id = id;
		this.name = name;
		this.mob = mob;
		this.email = email;
		this.capacity = capacity;
		this.orders = orders;
	}
	public Carrier() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMob() {
		return mob;
	}
	public void setMob(long mob) {
		this.mob = mob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public List<Order> getOrders() {
		return orders;
	}
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	@Override
	public String toString() {
		return "Carrier [id=" + id + ", name=" + name + ", mob=" + mob + ", email=" + email + ", capacity=" + capacity
				+ ", orders=" + orders + "]";
	}
	

}
