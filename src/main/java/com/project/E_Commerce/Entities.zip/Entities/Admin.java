package com.project.E_Commerce.Entities;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Admin {
	@Id
	private int id;
	private String name;
	private long mob;
	private String email;
	private List<Address> add;
	public Admin(int id, String name, long mob, String email, List<Address> add) {
		super();
		this.id = id;
		this.name = name;
		this.mob = mob;
		this.email = email;
		this.add = add;
	}
	public Admin() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMob() {
		return mob;
	}
	public void setMob(long mob) {
		this.mob = mob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Address> getAdd() {
		return add;
	}
	public void setAdd(List<Address> add) {
		this.add = add;
	}
	@Override
	public String toString() {
		return "Admin [id=" + id + ", name=" + name + ", mob=" + mob + ", email=" + email + ", add=" + add + "]";
	}
	
	

}
