package com.project.E_Commerce.Entities;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Customer {
	@Id
	private int id;
	private String name;
	private long mob;
	private String email;
	private List<Address> address;
	private List<Order> Orders;
	private List<Products> cart;
	public Customer(int id, String name, long mob, String email, List<Address> address, List<Order> orders,
			List<Products> cart) {
		super();
		this.id = id;
		this.name = name;
		this.mob = mob;
		this.email = email;
		this.address = address;
		Orders = orders;
		this.cart = cart;
	}
	public Customer() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMob() {
		return mob;
	}
	public void setMob(long mob) {
		this.mob = mob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	public List<Order> getOrders() {
		return Orders;
	}
	public void setOrders(List<Order> orders) {
		Orders = orders;
	}
	public List<Products> getCart() {
		return cart;
	}
	public void setCart(List<Products> cart) {
		this.cart = cart;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", mob=" + mob + ", email=" + email + ", address=" + address
				+ ", Orders=" + Orders + ", cart=" + cart + "]";
	}
	
 
}
