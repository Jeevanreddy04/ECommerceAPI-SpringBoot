package com.project.E_Commerce.Entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Address {
	@Id
	private int id;
	private String city;
	private int pincode;
	private String state;
	private String country;
	private String Description;
	private long mob;
	private String Addtype;
	public Address(int id, String city, int pincode, String state, String country, String description, long mob,
			String addtype) {
		super();
		this.id = id;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
		this.country = country;
		Description = description;
		this.mob = mob;
		Addtype = addtype;
	}
	public Address() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public long getMob() {
		return mob;
	}
	public void setMob(long mob) {
		this.mob = mob;
	}
	public String getAddtype() {
		return Addtype;
	}
	public void setAddtype(String addtype) {
		Addtype = addtype;
	}
	@Override
	public String toString() {
		return "Address [id=" + id + ", city=" + city + ", pincode=" + pincode + ", state=" + state + ", country="
				+ country + ", Description=" + Description + ", mob=" + mob + ", Addtype=" + Addtype + "]";
	}
	

}
