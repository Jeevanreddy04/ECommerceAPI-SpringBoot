package com.project.E_Commerce.Entities;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Order {
	@Id
	private int id;
	private List<Products> purchaselist;
	private Customer customer;
	private Carrier carrier;
	private String OrderStatus;
	private String date;
	private Address pickuploc;
	private Address deliveryloc;
	private String expecteddeliverydate;
	private int totalprice;
	public Order(int id, List<Products> purchaselist, Customer customer, Carrier carrier, String orderStatus,
			String date, Address pickuploc, Address deliveryloc, String expecteddeliverydate, int totalprice) {
		super();
		this.id = id;
		this.purchaselist = purchaselist;
		this.customer = customer;
		this.carrier = carrier;
		OrderStatus = orderStatus;
		this.date = date;
		this.pickuploc = pickuploc;
		this.deliveryloc = deliveryloc;
		this.expecteddeliverydate = expecteddeliverydate;
		this.totalprice = totalprice;
	}
	public Order() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<Products> getPurchaselist() {
		return purchaselist;
	}
	public void setPurchaselist(List<Products> purchaselist) {
		this.purchaselist = purchaselist;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Carrier getCarrier() {
		return carrier;
	}
	public void setCarrier(Carrier carrier) {
		this.carrier = carrier;
	}
	public String getOrderStatus() {
		return OrderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		OrderStatus = orderStatus;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Address getPickuploc() {
		return pickuploc;
	}
	public void setPickuploc(Address pickuploc) {
		this.pickuploc = pickuploc;
	}
	public Address getDeliveryloc() {
		return deliveryloc;
	}
	public void setDeliveryloc(Address deliveryloc) {
		this.deliveryloc = deliveryloc;
	}
	public String getExpecteddeliverydate() {
		return expecteddeliverydate;
	}
	public void setExpecteddeliverydate(String expecteddeliverydate) {
		this.expecteddeliverydate = expecteddeliverydate;
	}
	public int getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}
	@Override
	public String toString() {
		return "Order [id=" + id + ", purchaselist=" + purchaselist + ", customer=" + customer + ", carrier=" + carrier
				+ ", OrderStatus=" + OrderStatus + ", date=" + date + ", pickuploc=" + pickuploc + ", deliveryloc="
				+ deliveryloc + ", expecteddeliverydate=" + expecteddeliverydate + ", totalprice=" + totalprice + "]";
	}
	

}
