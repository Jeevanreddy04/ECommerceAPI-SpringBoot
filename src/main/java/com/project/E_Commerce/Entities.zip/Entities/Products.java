package com.project.E_Commerce.Entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Products {
	@Id
	private int id;
	private String name;
	private int quantity;
	private String category;
	private int PriceperUnit;
	private String brandName;
	private String description;
	private String availableStatus;
	public Products(int id, String name, int quantity, String category, int priceperUnit, String brandName,
			String description, String availableStatus) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.category = category;
		PriceperUnit = priceperUnit;
		this.brandName = brandName;
		this.description = description;
		this.availableStatus = availableStatus;
	}
	public Products() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getPriceperUnit() {
		return PriceperUnit;
	}
	public void setPriceperUnit(int priceperUnit) {
		PriceperUnit = priceperUnit;
	}
	public String getBrandName() {
		return brandName;
	}
	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAvailableStatus() {
		return availableStatus;
	}
	public void setAvailableStatus(String availableStatus) {
		this.availableStatus = availableStatus;
	}
	@Override
	public String toString() {
		return "Products [id=" + id + ", name=" + name + ", quantity=" + quantity + ", category=" + category
				+ ", PriceperUnit=" + PriceperUnit + ", brandName=" + brandName + ", description=" + description
				+ ", availableStatus=" + availableStatus + "]";
	}
	

}
